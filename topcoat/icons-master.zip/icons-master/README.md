TopCoat Icons
============

Open Source Icons designed for TopCoat





common icons:
(done: 13px,18px,24px,40px size)

1.share  
2.user  
3.favorite  
4.attachment  
5.checkmark  
6.remove  
7.add        
8.cancel  
9.lock   
10.unlock  
11.photo  
12.image  
13.back  
14.next  
15.settings  
16.wifi  
17.search  
18.right arrow  
19.left arrow  
20.up arrow  
21.down arrow  
22.call  
23.phone  
24.tablet  
25.laptop  
26.location  
27.expand  
28.collapse  
29.list view  
30.tile view  
31.text  
32.home  
33.brush  
34.pencil  
35.eye/visible  



to do:  
35.eye/visible off  
36.clock/time  
37.video camera  
38.alert  
39.email  
40.calendar  
41.print  
42.cart  
43.save  
44.cloud  
45.page  
46.user group  
47.battery full  
48.battery low  
49.battery empty  
50.bookmark  
51.chat  
52.upload  
53.download  
54.audio  
55.audio off  
56.comment/note  
57.address book  
58.map  
59.credit card  
60.news  
61.graph  
62.question mark  
63.scissors  
64.new  
65.CC creative commons  
66.video  
67.retweet  
68.refresh  
69.error  
70.delete  

social icons:
(done: 40px size)    
1.facebook  
2.twitter  
3.pinterest  
4.github  
5.dribble  
6.behance  
7.instagramm  
8.linkedin  
9.google-plus 
10.youtube  
11.vimeo  
12.flickr 
13.picasa  
14.tumblr  
15.wordpress  
16.blogger  
17.github-text  
18.path  

to do:
19.css  
20.stackoverflow  
21.html 5  
22.reddit  
23.Skype  


